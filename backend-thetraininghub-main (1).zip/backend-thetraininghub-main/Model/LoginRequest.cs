// Clase para recibir las credenciales del login
    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }